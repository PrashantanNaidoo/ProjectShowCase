import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class panelgui extends JPanel {
	int centerx;
	int centery;
	int xpos=0;
	int ypos=0;
	protected boolean moveforward = true;
	public  panelgui(){
		this.setPreferredSize(new Dimension(500,500));
		this.setBackground(Color.red);
		this.setVisible(true);
		
		Timer timer = new Timer(10, new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(xpos+10>=getWidth()|| ypos+10 >= getHeight()) {
					moveforward = false;
				}
				if(xpos-10<=0|| ypos-10 <= 0) {
					moveforward =true;
				}
				
				if(moveforward==true) {
					xpos+= 10;
					ypos+= 10;
					
				}
				else {
				     xpos-= 10;
				     ypos-= 10;
				     }
				repaint();

			}
		});
		
		 timer.start();
		
	     
	     
		this.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				if(e.getKeyCode()== KeyEvent.VK_ENTER) {
					if(timer.isRunning()== true) {
						timer.stop();
						
					}
					else {timer.start();}
					
				}
				
			}
		});
				
		 this.setFocusable(true);
	     this.requestFocusInWindow();
		 

		
	}
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		centerx = getWidth()/2;
		 centery = getHeight()/2;
		 
		
		
		Header(g);
		Line(g);
		drawball(g);
		
	}
	
	public void Header(Graphics g) {
		g.setColor(Color.black);
		g.setFont(new Font("Sans Serif",Font.BOLD,20));
		 FontMetrics fontMetrics = g.getFontMetrics();
	        int textWidth = fontMetrics.stringWidth("Ball on string");
		g.drawString("Ball on string",centerx-(textWidth/2), 30);
	}
	
	public void Line(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;
		g2d.setColor(Color.blue);
		g2d.setStroke(new BasicStroke(5));
		g2d.drawLine(0, 0, getWidth(), getHeight());
	}
	
	public void drawball(Graphics g) {
		g.setColor(Color.green);
		g.draw3DRect(xpos, ypos, 20, 20, true);
		g.setColor(Color.magenta);
		g.fillOval(xpos, ypos, 20, 20);
		
	}
	/* private class MyKeyListener extends KeyAdapter {
        @Override
        public void keyPressed(KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                if (timer.isRunning()) {
                    timer.stop();
                } else {
                    timer.start();
                }
            }
        }
    }

    // Inner class for ActionListener of Timer
    private class TimerListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if ((xPos + 10 >= getWidth()) || (yPos + 10 >= getHeight())) {
                forwardDirection = false;
            }
            if ((xPos <= 10) || (yPos <= 10)) {
                forwardDirection = true;
            }

            if (forwardDirection) {
                xPos += 10;
                yPos += 10;
            } else {
                xPos -= 10;
                yPos -= 10;
            }
            repaint();
        }
        class MouseHandler extends MouseAdapter {
    public void mouseClicked(MouseEvent ev) {
        if (ev.getX() <= 150) {
            currentColor = Color.BLACK;
        } else if (ev.getX() >= 150) {
            currentColor = Color.BLUE;
        }
        repaint();
    }
}
        
        */
	

}
