import java.util.Scanner;
import java.util.Random;

public class BattleShips {

    private char[][] grid = new char [10][10];
    //TODO: Add your code here
    

    public BattleShips() {
    	initializeGrid();
    	placeShips();
    	
    	
    }
    
    public void initializeGrid() {
    	for(int i=0;i < grid.length; i++) {
    		for(int j =0; j< grid.length;j++) {
    			grid[i][j] = ' ';
    				
    			}	
    		}
    	
    }
    
    public void print() {
    	for(int i=0;i < grid.length; i++) {
    		System.out.println(" ");
    		for(int j =0; j< grid.length;j++) {
    			if(grid[i][j]=='S') {
    				System.out.print("[ ]"+ " ");
    			}
    			
    			else{System.out.print("["+grid[i][j] +"]"+ " ");}
    				
    			}
    			
    		}
    		
    	}
    
     public void printReal() {   //used for testing
    	for(int i=0;i < grid.length; i++) {
    		System.out.println(" ");
    		for(int j =0; j< grid.length;j++) {
    			
    			
    			System.out.print("["+grid[i][j] +"]"+ " ");
    				
    			}
    			
    		}
    		
    	}
    
    public void placeShips() {

    	
    	int[] arrShips = {1,2,3,4,5}; //sizes of each ship
    	Random random = new Random();
    	boolean bflag ;
    	int randomrow ;
    	int randomcol;
    	int countships = 0 ;
    	int countspace=0;
    	boolean bspace ;
    	int available;
    	
    	
    	while (countships < 5) {
    		bflag = false;
    		countspace=0;
    		bspace= false;
    		
    		
    		 do {
    			 randomrow = random.nextInt(10); //gets random row number to place ship
    			 randomcol = random.nextInt(10); //gets random column number to place ship
    			
    			 
    			 if(grid[randomrow][randomcol] !=' ') {
    				 continue;
    			 }
    			 
    			 available = grid.length-randomcol; //Available spaces after start
    			 if(available==0) {
    				 continue;
    			 }
    			 
    			 if(arrShips[countships]+randomcol>10) {
    				 continue; 
    			 }
    			 
    	    	 bspace = false;

    			 
    			 for(int m = 0;m<(available);m++) {
    				 if((grid[randomrow][randomcol+m]== ' ') && (bspace == false)) {
    					 countspace++;	 //count the number of consecutive spaces  after the given co-ordinate
    				 }
    				 else {bspace = true;
    				}	 
    				 
    			 }
    			 
    			 if(arrShips[countships]<=countspace) {// if the amount of spaces a ship takes is <= the available space and consectuvive spaces, bflag is true
    				 bflag = true;
    				 break;
    				 
    			 }
    	   
    	        } while (bflag == false);
    		 
    		 
    		 
    		 if (bflag== true) { 
    			 for(int m = 0;m<arrShips[countships];m++) { //places ships
    				 grid[randomrow][randomcol+m]= 'S';


    			 }  
    			
    			 countships ++;
    		 }
   	
    	}
    	//System.out.println(tries);
    }//print ships end
    
    
    public boolean canFire(int row,int col) {
    	
    	if((grid[row][col]=='H') ||(grid[row][col]=='M')) {
    		return false;	
    	}
    	else {
    	return true;
    	}
    }

    public void processFire(int row,int col) {
    	
    	if(grid[row][col]== 'S' ) {
    		grid[row][col]='H';
    	}
    	else {grid[row][col]='M';};
    	
    }

    public boolean gameOver() {
    	boolean bflag = true;
    	for(int i=0;i < grid.length; i++) {
    		for(int j =0; j< grid.length;j++) {
    			if(grid[i][j]=='S') {
    				bflag= false;
    			}
    			
    			}
    			
    		}
    	return bflag;
    }

}



