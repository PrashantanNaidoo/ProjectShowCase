import java.awt.print.Printable;
import java.util.Scanner;

public class BattleShipsApp {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		// TODO: Add your code here
        BattleShips game = new BattleShips();
        //game.print();
        
       // game.printReal();
        System.out.println(" ");
        while(!game.gameOver()) {
        	game.print();
        	System.out.println(" ");
        	System.out.println("Enter a row and column to fire on:");
        	
        	int row = sc.nextInt();
        	int col = sc.nextInt();
        	if((row>9) || (col>9)) {
        		System.out.println("Out of bounds");
        		continue;
        	}
        	
        	if(game.canFire(row, col)==false) {
        		System.out.println("Cannot fire here");
        		continue;
        	}
        	System.out.println("row(0-9) : " + row);
        	System.out.println("col(0-9) : " + col);
        	
        	game.processFire(row, col);	
        }
        if(game.gameOver()== true) {
        	System.out.println("Congratulations! YOU WON");
        }
        

	}
}
