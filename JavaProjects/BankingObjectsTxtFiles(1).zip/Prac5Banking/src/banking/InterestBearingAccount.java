package banking;

public interface InterestBearingAccount {
    void addInterest(double interestRate);
    
}
