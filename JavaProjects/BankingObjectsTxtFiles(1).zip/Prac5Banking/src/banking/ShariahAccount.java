package banking;

import banking.BankAccount.Transaction;

public class ShariahAccount extends BankAccount{

	public ShariahAccount(int accountNumber, String accountHolder, double openingBalanc) {
		// TODO Auto-generated constructor stub
		super( accountNumber,  accountHolder,  openingBalanc);
	}
	
	@Override
	public  void deductFees() {
		int count =0;
		double total = 0;
		for(Transaction transaction: super.transactions) {
			count += 1;
			if(count>5) {
				total += 1.80;
			}
			
		}
	//	super.balance-= total;
		Transaction transaction = new Transaction(31,3,2024,0,null,total);	
		super.transactions.add(transaction);
		//processTransaction(transaction);

	
	}
	
	@Override
	public  boolean withdraw(double amount) {
		if(super.balance-amount<0) {
			return false;
		}
		else {
			balance-= amount;
			transactionCount+= 1;
			//System.out.println(balance+" shariah "+amount+ " "+ super.getAccountNumber());

			return true;
		}
		
	}

}
