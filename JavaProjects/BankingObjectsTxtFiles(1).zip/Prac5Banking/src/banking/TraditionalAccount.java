package banking;

public class TraditionalAccount extends BankAccount implements InterestBearingAccount {
	//protected double balance;

	public TraditionalAccount(int accountNumber, String accountHolder, double openingBalance) {
		super(accountNumber,accountHolder,openingBalance);
	//	balance = openingBalance;
		
	}
	
	@Override
	public  void deductFees() {
		//super.balance -= 50;
		
		transactionCount= 0;
		Transaction transaction = new Transaction(31,3,2024,0,null,50.0);		
		super.transactions.add(transaction);
		//processTransaction(transaction);



	}
	
	@Override
	public  boolean withdraw(double amount) {
	

		if(super.balance-amount<500) {
			return false;
			
		}
		else {
			balance-= amount;
			transactionCount+= 1;
			
			//System.out.println(balance+" traditional "+amount+ " "+ super.getAccountNumber());
			
			
			return true;
		}
		

	}
	
	@Override
	public void addInterest(double interestRate) {
		if(super.balance>500) {
			double amount = balance*(interestRate);
			double truncatedAmount = (double) ((int) (amount * 10)) / 10;

			Transaction transaction = new Transaction(31,3,2024,1,this,truncatedAmount);	
			super.transactions.add(transaction);
			//processTransaction(transaction);
		}
		
		
	}
	
	

	

}
