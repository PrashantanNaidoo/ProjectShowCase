package banking;

import java.util.ArrayList;
import java.util.Scanner;

import banking.BankAccount.Transaction;

import java.io.*;

public class Main {

    public static void main(String[] args) {
	// write your code here
    	 ArrayList<BankAccount> accounts = new ArrayList<BankAccount>();

    	 
    	 String text= "accounts.txt";
    	 String text2 = "transact.txt";
    	 readaccounts(text,accounts);
    	 readtransactions(text2, accounts);
    	 System.out.println("Account Statements :"+ "\n");
    	 
    	 for(BankAccount account : accounts) {
    		 if(account instanceof TraditionalAccount) {
     			account = (TraditionalAccount)account;
     			((TraditionalAccount) account).addInterest(0.015);
     		}
     		else {account= (ShariahAccount)account;
 		    }
    		 account.deductFees();
    		 
    	 }
    	 
    	 executetransactions(accounts);

    	 
    	 for(BankAccount account : accounts) {
    		 System.out.println(account.toString());
    		 account.printStatement();
    		 System.out.println("================================");
    	 }
    
    	 
    	 
    	 
    	
    	
    	
    }
    
    public static void readaccounts(String text, ArrayList<BankAccount>accounts) {

    	
    	
   
    	try {
    		File file = new File(text);
        	Scanner scanner = new Scanner(file);
        	String line;
        	
        	scanner.nextLine();
        	
        	while(scanner.hasNextLine()) {
        		line = scanner.nextLine();
        		String[] parts = line.split("\\s+");
        		
        		if(parts[1].equals("Traditional")) {
        			TraditionalAccount account = new TraditionalAccount(Integer.parseInt(parts[0]), parts[2]+parts[3], Double.parseDouble(parts[4]));
        			accounts.add(account);
        		}
        		else {
        			ShariahAccount account = new ShariahAccount(Integer.parseInt(parts[0]), parts[2]+parts[3], Double.parseDouble(parts[4]));
        			accounts.add(account);
        		}
        
        	}
        	scanner.close();
    	}
    		
    		
    		
    	catch(FileNotFoundException e){
    		System.out.println("Cant find accounts file");
    	}	
    }

    public static void readtransactions(String text, ArrayList<BankAccount>accounts) {
    	
    	
    	try {
    		File file = new File(text);
        	Scanner scanner = new Scanner(file);
        	String line;
        	
        	scanner.nextLine();
        	int type = 0;
        	
        	while(scanner.hasNextLine()) {
        		line = scanner.nextLine();
        		String[] parts = line.split("\\s+");
        		BankAccount toAccount=null;
        		BankAccount current = findbankaccount(Integer.parseInt(parts[3]), accounts);
		        double amount =Double.parseDouble(parts[5]);   // amount


        	/*	if(current instanceof TraditionalAccount) {
        			current = (TraditionalAccount)current;
        		}
        		else {current= (ShariahAccount)current;}  */
        		
        			if(parts[4].equals("withdraw")) {
        				type=0;
        				toAccount= null;
        			//	current.withdraw(amount);
        			}
        			else if(parts[4].equals("deposit")) {
        				type=1;
        				toAccount = null;
        			//	current.deposit(amount);

        			}
        			else if(parts[4].equals("transfer")) {
        				type=2;
        				toAccount = findbankaccount(Integer.parseInt(parts[6]), accounts);
        			//	current.transferTo(toAccount, amount);
        				

        			}
        		
        		    Transaction transaction = current.new Transaction(
        		        Integer.parseInt(parts[0]),    // day
        		        Integer.parseInt(parts[1]),    // month
        		        Integer.parseInt(parts[2]),    // year
        		        type,                          // transactionType
        		        toAccount,                       // toAccount
        		        amount  // amount
        		    );
        		    current.transactions.add(transaction);
        		    if(parts[4].equals("transfer")) {
        		    	toAccount.transactions.add(transaction);
        		    	
        	
        			}
        		    
        		    
        
        		
        		
        
        	}
        	scanner.close();
    	}
    		
    		
    		
    	catch(FileNotFoundException e){
    		System.out.println("Cant find transactions  file");
    	}	
    	
    	
    	
    }
    
    public static BankAccount findbankaccount(int accountnumber,ArrayList<BankAccount> accounts) {

    	
    	for(BankAccount account : accounts) {
    		if(account.getAccountNumber()== accountnumber) {
    			return account;
    		}
    	}
    	return null;
    }
    
    public static void executetransactions(ArrayList<BankAccount> accounts) {
    	
    	for(BankAccount account: accounts) {
    		if(account instanceof TraditionalAccount) {
    			account = (TraditionalAccount)account;
    		//	((TraditionalAccount) account).addInterest(1.5);
    		}
    		else {account= (ShariahAccount)account;
			
		    }
    		for(Transaction transaction : account.transactions) {
    			
    			
    			
    			if(transaction.transactionType ==0) {
    				
    				if(account.withdraw(transaction.amount)==false) {
    					transaction.cancelled= true;
    					
    				}
    			
    			}
    				
    			
    			else if(transaction.transactionType ==1) {
    				account.deposit(transaction.amount);
    			}
    				
    			
                else if(transaction.transactionType ==2) {
                	account.transferTo( transaction.toAccount,transaction.amount);
                }
                	
    			
    			}
    		
    	}
    	
    }
    



    

}

