package checkers;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Board extends JPanel implements MouseListener {
	private static final int numRowCol = 8;
	private Square[][] squares = new Square[numRowCol][numRowCol];
	private Square firstSelected = null;
	private Square secondSelected = null;
	private static final int squaresize=50 ;
	private boolean isBlackTurn = true;
	public int x,y,oldx,oldy,count,piececolor,oppX,oppY;
	public boolean highlight ,captureflag,checkflag;

	public Board() {
		// TODO create squares and add pieces to each square to match the default
		// configuration of the
		// board from the image\
		count=0;
		this.addMouseListener(this);
		setPreferredSize(new Dimension(Square.SIZE * numRowCol, Square.SIZE * numRowCol));
		
		//creates squares for grid
		boolean flag = false;
		for(int i =0; i<8;i++) {
			for(int j =0;j<8;j++) {
				if((i+j)% 2 ==0) {
					flag = true;	
				}
				else {flag= false;}
				Square square = new Square(i,j,flag);
				squares[i][j]= square;

			}
		}
		
		
		// creates black pieces
		for(int i =0; i<8;i++) {
			for(int j =0;j<3;j++) {
				if((i+j)% 2 ==0) {
					Piece piece = new Piece(0);
					//piece.draw(g, i, j, Square.SIZE, Square.SIZE);
					squares[i][j].addPiece(piece);
					
				}
				
			}
		}
		//creates red pieces
		for(int i =0; i<8;i++) {
			for(int j =5;j<8;j++) {
				if((i+j)% 2 ==0) {
					Piece piece = new Piece(1);
				//	piece.draw(g, i, j, Square.SIZE, Square.SIZE);
					squares[i][j].addPiece(piece);
					
				}
				
			}
		}	
	}

	public void paintComponent(Graphics g) {
		// TODO draw each square
		super.paintComponent(g);
		
		//paints grid
		for(int i =0; i<8;i++) {
			for(int j =0;j<8;j++) {
				squares[i][j].draw(g);
				
			}
		}
		
		//paints pieces
		for(int i =0; i<8;i++) {
			for(int j =0;j<8;j++) {
				if(squares[i][j].getPiece() != null) {
					squares[i][j].getPiece().draw(g, i, j, Square.SIZE, Square.SIZE);
					
				}
				
			}
		}
		if (highlight== true) {
			squares[x][y].highlight(g,x,y);
			
		}
	}

	// TODO Select the first Square and then select the second square. Execute the
	// move IF IT IS VALID
	@Override
	public void mouseClicked(MouseEvent e) {
		 x = e.getX()/60;
		 y = e.getY()/60;
		 boolean bcheck= false;
		 checkflag=false;
		 captureflag= false;
		//JOptionPane.showMessageDialog(this,x+","+ y);
		 //check if dark shaded square is selected to continue moving
		
			//gets the number of whose turn
			if(isBlackTurn==true) {
				piececolor=0;	
			}
			else {piececolor=1;}
		    ////////////////////////////////
			
			//checks if correct color
			if(squares[x][y].getPiece()!=null&&squares[x][y].getPiece().getColor() != piececolor) {JOptionPane.showMessageDialog(this, "incorrect piece color");
			highlight=false;}
			
            //checks if a piece is selected
			else if(squares[x][y].getPiece()==null && highlight== false) {
				JOptionPane.showMessageDialog(this, "Select A Piece");
				highlight =false;
			}
			
			//checks if a piece is being moved to a null space
			else if(squares[x][y].getPiece()==null && highlight== true) {
				highlight= false;
				bcheck = true;
			}
            // selecting a piece to move if other conditions fail
			else {
				highlight=true;
				oldx= x;
				oldy=y;}
		
		//////////////////////////////////////////////////////////////			
			//if all conditions are true the check variable is true and we are ready to move a piece
		if(bcheck== true) {			
			move();
		}
		
		repaint();

			

		
		
		

	}

	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}

	public void capture() {
		// TODO execute capture 
		// Hint: to reuse code, you can call move within this method

		//move();
		squares[oppX][oppY].removePiece();
		
	}

	public void move() {
		// TODO execute move
		
		Piece p = squares[oldx][oldy].getPiece();
		
		//checks to see if its a valid move
        if(checkMove()== true || captureflag ==true) {
		squares[x][y].addPiece(p);
		squares[oldx][oldy].removePiece();
		isBlackTurn = !isBlackTurn;
		checkWin();
        }
        
        //
        
        

	}
	//checkmove checks to see if the player is moving the piece to a valid location
	public boolean checkMove() {
		 captureflag = false;
		 checkflag= true;
		//checks if user is trying to move to a white piece
				if (squares[x][y].getDark() != true) {
				    JOptionPane.showMessageDialog(this, "Cannot move to white square.");
				    checkflag=false;
				}
				
				
		        //checks if user is trying to move backwards
				if (y - oldy < 0 && isBlackTurn== true  ) {
				    JOptionPane.showMessageDialog(this, "Cannot move backwards.");
				    checkflag=false;
				}
				else if(oldy-y<0 &&  isBlackTurn== false) {
					JOptionPane.showMessageDialog(this, "Cannot move backwards.");
				    checkflag=false;
				}
				//checks if user is trying to capture a piece
				//black turn capturing
				if(Math.abs(oldx-x)==2 && Math.abs(oldy-y)==2 && isBlackTurn== true) {
					if(x-oldx<0) {
						if ((squares[x+1][y-1].getPiece()!= null) && (squares[x+1][y-1].getPiece().getColor()==1)) {
							captureflag=true;
							oppX=x+1;
							oppY=y-1;
							capture();
							return checkflag;
						}
					}
					if(x-oldx>0) {
						if ((squares[x-1][y-1].getPiece()!= null)&&(squares[x-1][y-1].getPiece().getColor()==1)) {
							captureflag=true;
							oppX=x-1;
							oppY=y-1;
							capture();
							return checkflag;
									
						}
					}
				} 
				//red turn capturing
				if(Math.abs(x-oldx)==2 && Math.abs(y-oldy)==2 && isBlackTurn== false) {
					if(x-oldx<0) {
						if ((squares[x+1][y+1].getPiece()!= null)&&( squares[x+1][y+1].getPiece().getColor()==0)) {
							captureflag=true;
							oppX=x+1;
							oppY=y+1;
							capture();
							return checkflag;
						}
					}
					if(x-oldx>0) {
						if ((squares[x-1][y+1].getPiece()!= null)&&( squares[x-1][y+1].getPiece().getColor()==0)) {
							captureflag=true;
							oppX=x-1;
							oppY=y+1;
							capture();
							return checkflag;
									
						}
					}
				} 
		        //checks if user is trying to move a piece more than 1 space
				if ((Math.abs(oldx-x)>1) || (Math.abs(oldy-y)>1)) {
				    JOptionPane.showMessageDialog(this, "Cannot move piece here");
				    checkflag=false;
				}
		
		return checkflag;
	}
	
	public void checkWin() {
		// TODO check if one of the players has won the game after a move is executed 
		checkRemainderPieces();
		String color ="";
		if(isBlackTurn==true) {
			color = "red";
		}
		else { color = "black";}
		
		if(checkAvailableMoves()== true) {
			JOptionPane.showMessageDialog(this,color+" has won" );
		}
		
		
		
		
	}
	
	//checks if each side has remaining pieces
	public void checkRemainderPieces() {
		boolean haspiece =false;
		String color ="";
		for(int i =0 ; i < 8;i++ ) {
			for(int j=0;j<8;j++) {
				if(isBlackTurn==true &&squares[i][j].getPiece() != null&& squares[i][j].getPiece().getColor()== 0) {
					haspiece= true;
					color= "red";

				}
				else if(isBlackTurn==false &&squares[i][j].getPiece() != null&& squares[i][j].getPiece().getColor()== 1) {
					haspiece = true;
					color = "black";	
				}
			}
		}
		if(haspiece== false) {
			JOptionPane.showMessageDialog(this, color+" has won bruh");
		}
	}
	
	//checks if red has avaialble spaces to move
	public boolean canRedMove(int a, int b) {
		//check 1 space in front
		if(((b-1)>= 0)&& ((a-1)>=0)) {
			if( squares[a-1][b-1].getPiece()==null) {
				return true;
			}
		}	
		
		if((b-1)>=0 && a+1<=7) {
			if((squares[a+1][b-1].getPiece()==null )) {
				return true;
			}
		}	
		 
		//check if can capture piece
		
		if(((b-2)>=0&& a-2>=0) ) {
			if ((squares[a-2][b-2].getPiece()== null) && squares[a-1][b-1].getPiece()!= null && squares[a-1][b-1].getPiece().getColor()==0) {
				return true;
			}
		}	
		
		if(((b-2)>=0&& a+2<=7) ) {
			if ((squares[a+2][b-2].getPiece()== null) && squares[a+1][b-1].getPiece()!= null&& squares[a+1][b-1].getPiece().getColor()==0) {
				return true;
			}
		}	
		
		
		//if no moves can be made return false

		return false;
	}
	//checks if theres avaialble space for black to move
	public boolean canBlackMove(int a, int b) {
		//check 1 space in front
		if(b+1<=7 && a-1>=0)  {
			if( squares[a-1][b+1].getPiece()==null) {
				return true;
			}
		}	
		
		if((b+1)<=7 && a+1<=7) {
			if((squares[a+1][b+1].getPiece()==null )) {
				return true;
			}
		}	
		
		//check if can capture piece
		
		if(((b+2)<=7&& a-2>=0) ) {
			if ((squares[a-2][b+2].getPiece()== null) && squares[a-1][b+1].getPiece()!= null&& squares[a-1][b+1].getPiece().getColor()==1) {
				return true;
			}
		}	
		
		if(((b+2)<=7&& a+2<=7) ) {
			if ((squares[a+2][b+2].getPiece()== null) && squares[a+1][b+1].getPiece()!= null&& squares[a+1][b+1].getPiece().getColor()==1) {
				return true;
			}
		}	
		
		
		//if no moves can be made return false
		// JOptionPane.showMessageDialog(this, String.valueOf(a)+","+String.valueOf(b));

		return false;
	}
	
	
	//check availability of black and red throughought entire array
	public boolean checkAvailableMoves() {
		for(int i =0 ; i < 8;i++ ) {
			for(int j=0;j<8;j++) {
				if((isBlackTurn==true) &&(squares[i][j].getPiece() != null)&& (squares[i][j].getPiece().getColor()== 0)) {
					if (canBlackMove(i, j)== true){
						//						JOptionPane.showMessageDialog(this, "red won");	
						return false;
					}
				}
				
				 if((isBlackTurn==false) &&(squares[i][j].getPiece() != null)&&( squares[i][j].getPiece().getColor()== 1)) {
					 if (canRedMove(i, j)== true){
						 return false;

					 }	
				
					}
			} 
		}
		return true;
		
	}

}
