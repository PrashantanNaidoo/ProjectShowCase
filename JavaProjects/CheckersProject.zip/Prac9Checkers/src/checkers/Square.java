package checkers;

import java.awt.*;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Square {
	
	public static final int SIZE = 60;
	private Piece p = null;
	private int x, y;
	private boolean isDark;
	
	public Square(int row, int col,boolean isDark) {
		x = col * SIZE;
		y = row * SIZE;
		this.isDark = isDark;
	}
	
	public boolean getDark() {
		return isDark;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}

	public Piece getPiece() {
		return p;
	}

	public void addPiece(Piece p){
		this.p = p;
	}
	
	public void removePiece(){
		p = null;
	}

	public void draw(Graphics g) {
		// TODO: draw the square
		if (isDark == true) {
			g.setColor(Color.gray);
		}
		else {g.setColor(Color.white);}
		g.fillRect(x, y, SIZE, SIZE);
	}	
	public void highlight(Graphics g,int x ,int y) {
		Graphics2D g2d =  (Graphics2D)g;
		g.setColor(Color.blue);
		g2d.setStroke(new BasicStroke(5));
		g2d.drawRect(x*SIZE, y*SIZE, SIZE, SIZE);

		
	}
}
