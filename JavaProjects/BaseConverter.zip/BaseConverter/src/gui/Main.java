package gui;

import javax.swing.JFrame;


public class Main {
	public static void main(String[] args) {
		JFrame myFrame = new JFrame() ;
		
		myFrame.setSize (400,400) ;
		myFrame.setLocationRelativeTo(null);
		myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myFrame.setTitle("Base Converter");
		myFrame.add(new ConverterPanel() ) ;
		myFrame.setVisible(true);
	}
}