package gui;

import javax.swing.*;

import org.w3c.dom.Text;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ConverterPanel extends JPanel {
	JButton btnclear,btnconvert,btnback;
	JTextField anstxt;
	JComboBox<String> fbasecmb,tbasecmb;
	JTextField numtxt;
	public ConverterPanel() {
//number panel		
		 JPanel numberpnl= new JPanel(new BorderLayout());
		  numtxt = new JTextField();
		 JLabel numlbl = new JLabel("Enter number   ");
		 numberpnl.add(numlbl,BorderLayout.WEST);
		 numberpnl.add(numtxt,BorderLayout.CENTER);

//fbase panel		
		JPanel fbasepnl = new JPanel(new BorderLayout());
		 JLabel fbaselbl = new JLabel("Convert F          ");
		 String[] options = {"binary", "octal", "decimal","hexadecimal"};
		  fbasecmb= new JComboBox<String>(options); 
		 fbasepnl.add(fbaselbl,BorderLayout.WEST);
		 fbasepnl.add(fbasecmb,BorderLayout.CENTER);
		 
//tobase panel		 
		 
		 JPanel tbasepnl = new JPanel(new BorderLayout());
		 JLabel tbaselbl = new JLabel("Convert T          ");
		 
		  tbasecmb= new JComboBox<String>(options); 
		 tbasepnl.add(tbaselbl,BorderLayout.WEST);
		 tbasepnl.add(tbasecmb,BorderLayout.CENTER);
		 
		 //button panel
		 JPanel btnpnl = new JPanel(new BorderLayout());
		 ActionListener command = new ButtonListener();
		  btnclear = new JButton("clear");
		  btnclear.addActionListener(command);
		  btnconvert = new JButton("convert");
		  btnconvert.addActionListener(command);
		  btnback = new JButton("back");
		  btnback.addActionListener(command);
		 btnpnl.add(btnclear,BorderLayout.WEST);
		 btnpnl.add(btnconvert,BorderLayout.CENTER);
		 btnpnl.add(btnback,BorderLayout.EAST);
		 
		 
			//answer panel

		 JPanel answerpnl = new JPanel(new BorderLayout());
		 JLabel anslbl = new JLabel("Answer              ");
		  anstxt = new JTextField();
		 anstxt.setEditable(false);
		 answerpnl.add(anslbl,BorderLayout.WEST);
		 answerpnl.add(anstxt,BorderLayout.CENTER);
		 
		 this.setLayout(new GridLayout(5,1));
		 this.add(numberpnl);
		 this.add(fbasepnl);
		 this.add(tbasepnl);
		 this.add(btnpnl);
		 this.add(answerpnl);
		 
		 
		 
		 	
	}
	
	public class ButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == btnconvert) {
				
				try {
					String ftext = (String)fbasecmb.getSelectedItem();
					String ttext = (String)tbasecmb.getSelectedItem();
					String num = numtxt.getText();
					int fvalue = 0;
					String tvalue ="";
					
					if(ftext.equals("binary")) {
						fvalue = Integer.parseInt(num,2);	
					}
					else if(ftext.equals("octal")) {
						fvalue= Integer.parseInt(num,8);	
					}
					else if(ftext.equals("decimal")) {
						fvalue= Integer.parseInt(num,10);	
					}
					else if(ftext.equals("hexadecimal")) {
						fvalue= Integer.parseInt(num,16);	
					}
					//========================================
					if(ttext.equals("binary")) {
						tvalue = Integer.toBinaryString(fvalue);	
					}
					else if(ttext.equals("octal")) {
						tvalue= Integer.toOctalString(fvalue);	
					}
					else if(ttext.equals("decimal")) {
						tvalue= String.valueOf( Integer.parseInt(String.valueOf(fvalue),10));	
					}
					else if(ttext.equals("hexadecimal")) {
						tvalue= Integer.toHexString(fvalue);	
					}
					anstxt.setText(tvalue);
					
				}catch(NumberFormatException err){
					anstxt.setText("invalid text");
					
				}
				
			}
			
			if(e.getSource()== btnback) {
				String text = numtxt.getText();
				
				if(text.length()>=1 ) {
					text = text.substring(0,text.length()-1);			
				}	
				numtxt.setText(text);
			}
			
			if(e.getSource()== btnclear) {
				numtxt.setText("");;
			}
			
		}
	}


	
	
	
	
	
	    

}
