package cardGames;
import java.util.*;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Deck d = new Deck();
       
        
        Hand player = new Hand();
        Hand dealer = new Hand();
        
        d.shuffle();
        
        player.addCard(d.dealCard());
        player.addCard(d.dealCard());
        
        dealer.addCard(d.dealCard());
        System.out.println("Dealers cards:");
        dealer.ShowCards();
        System.out.println("?");
        dealer.addCard(d.dealCard());
        
        System.out.println("Value of dealer cards = "+"?");

        
        System.out.println("Players cards:");
        player.ShowCards();
        System.out.println("Value of player cards = "+player.value());
        
    	System.out.println("HIT OR STAND?");
    	
    	System.out.println("===========");

        boolean blackflag =false;
        
        
         if(player.checkBlackJack()== true &&dealer.checkBlackJack()== true) {//checks for blackjack hand
        	System.out.println("BlackJack, TIE");
        	blackflag = true;
        	
        }
        
        else if(player.checkBlackJack()== true) {
        	System.out.println("BlackJack, Player Wins!!!");
        	blackflag = true;
        	
        }
        else if(dealer.checkBlackJack()== true) {
        	System.out.println("BlackJack, Dealer Wins!!!");
        	blackflag = true;
        	
        }

        Scanner word = new Scanner(System.in);

        while( player.value() <21&& blackflag == false) {
        	String input = word.nextLine();
        	System.out.println("HIT OR STAND?");
        	if(input.equals("H")) {
        	
        	player.addCard(d.dealCard());
        	System.out.println("===========");
        	
        	System.out.println("Players cards:");
            player.ShowCards();
            System.out.println("Value of player cards = "+player.value());
           
        	}
        	else {break;}


        }
        word.close();
        
        while(dealer.value()<17 && player.value()<=21&& blackflag == false && dealer.value()<player.value()) { //dealer stands on 17-universal blackjack rule
        	dealer.addCard(d.dealCard());        	
        }
        System.out.println("Dealers cards:");
        dealer.ShowCards();
        System.out.println("Value of dealer cards = " + dealer.value());
        
        if(player.value()==dealer.value()&& blackflag == false) {
        	System.out.println("TIE");
        }
     
        
        
        
        else if(player.value()>21&& blackflag == false) {
        	System.out.println("Bust, Dealer Wins");
        	
        }
        
        else if(dealer.value()>21&& blackflag == false) {
        	System.out.println("Bust, Player Wins");
        	
        }
        
        else if(player.value()>dealer.value()&& blackflag == false) {
        	System.out.println("Player Wins");
        	
        }
        
        else if(dealer.value()>player.value()&& blackflag == false) {
        	System.out.println("Dealer Wins");
        	
        }
    
    }
    
}
