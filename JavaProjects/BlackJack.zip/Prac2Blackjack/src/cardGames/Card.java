package cardGames; /**
 * 
 */

public class Card {

	public static final int HEARTS = 0;
	public static final int CLUBS = 1;
	public static final int SPADES = 2;
	public static final int DIAMONDS = 3;

	private int suit;
	private int value;

	/**
	 * @param suit
	 * @param value
	 */
	public Card(int suit, int value) {
		this.suit = suit;
		this.value = value;
	}

	/**
	 * Represent the card as string for printing Now the cardGames.Card can be printed with
	 * println
	 */
	public String toString() {
		//return "cardGames.Card [suit=" + suit + ", value=" + value + "]";
		return getSuitAsString(suit)+ " "+ getValueAsString(value);
	}

	/**
	 * @return the value
	 */
	public int getValue() {
		
		return value;
	}

	/**
	 * @return the suit
	 */
	public int getSuit() {
		return suit;
	}
	
	public String getSuitAsString(int suit) {
		this.suit= suit;
		
		if (suit == HEARTS) {
			return "H";
		}
		else if(suit==SPADES) {
			return "S";
		}
		else if(suit==CLUBS) {
			return "C";	
		}
		else {return "D";}
		
	}
	
	public String getValueAsString(int value){
		this.value= value;
		
		if(value== 1) {
			return "A";
		}
		else if(value== 2) {
			return "2";
		}
		else if(value==3 ) {
			return "3";
		}
		else if(value==4 ) {
			return "4";
		}
		else if(value==5 ) {
			return "5";
		}
		else if(value== 6) {
			return "6";
		}
		else if(value== 7) {
			return "7";
		}
		else if(value== 8) {
			return "8";
		}
		else if(value== 9) {
			return "9";
		}
		else if(value== 10) {
			return "10";
		}
		else if(value== 11) {
			return "J";
		}
		else if(value==12 ) {
			return "Q";
		}
		else {return "K";}
		
	}
	public boolean isFaceCard() {   //checks if card is a face
		if (value> 10) {
			return true;
		}else {return false;}
			
	}
	
	public boolean isAce() {  //checks if card is ace
		if (value ==1) {
			return true;
		}
		else {return false;}
	}

}
