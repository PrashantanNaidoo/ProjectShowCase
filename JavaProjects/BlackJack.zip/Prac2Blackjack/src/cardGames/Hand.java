package cardGames; /**
 * 
 */

public class Hand {
	private Card[] hand;
	private int numcards ;
	
	//creates a hand to hold 10 cards
	public Hand() {
		this.hand = new Card[10];
		numcards = 0;
	}
	
	//create a hand to hold num cards
	public Hand(int num) {
		this.hand = new Card[num];
		numcards = 0;
		
	}
	
	//add a card to this hand
	public void addCard(Card card) {
		if(numcards<10) {
			hand[numcards] = card;
			numcards++;
		}
		
	}

	//remove the card at index i from this hand
	public void removeCard(int num) {
		
		if(numcards == 0) {
			System.out.println("No cards to remove!");
		}else {
		for(int i=num; i<numcards-1;i++) {
			hand[i] = hand[i+1];	
		}
		hand[numcards-1]= null;
		numcards--;
		}
		
	}
	
	//return the value of the cards in this hand
	public int value() {
		int total = 0;
		for(int i=0;i<numcards;i++) {
			if(hand[i].isAce()) {
				if(total+ 11<=21) {
					total = total +11;
				}
				else {total=total+1;}
				
			}
			else if(hand[i].isFaceCard()){total=total +10;}
			else {total = hand[i].getValue()+ total;};
			
		}
		return total;
		
	}
	
	public void ShowCards() { //shows all cards played till now
		for (int i =0;i<hand.length;i++) {
			if(hand[i] != null) {
			System.out.println(hand[i].toString());}
		}
		
	}
	
	public boolean checkBlackJack() { //checks if a blackjack hand has beend dealt
		boolean bface = false;
		boolean bace = false;
		for(int i=0;i<numcards;i++) {
			if(hand[i].isFaceCard()) {
				bface = true;	
			}
			if(hand[i].isAce()) {
				bace= true;
			}
		}
		
		
		if(bace== true && bface== true) {
			return true;
			
		}
		else {return false;}

	}
	
	
	
}
